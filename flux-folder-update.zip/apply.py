from pathlib import Path
import json,zipfile,hashlib,subprocess
root=Path('.')
with zipfile.ZipFile('flux-folder-update.zip') as z:
    m=json.loads(z.read('manifest.json'))
    for name,old in m['files'].items():
        p=root/name
        assert not name.startswith(('/', '.github/')) and '..' not in p.parts
        actual=hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None
        assert actual==old, 'Concurrent edit, refusing to overwrite '+name
    if m['repo']=='assets':
        old=root/'post/stream';new=root/'post/flux'
        assert old.is_dir() and not new.exists()
        before={p.relative_to(old).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in old.rglob('*') if p.is_file()}
        subprocess.run(['git','mv','post/stream','post/flux'],check=True)
        after={p.relative_to(new).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in new.rglob('*') if p.is_file()}
        assert before==after, 'Image bytes changed'
        print('Moved',len(after),'files with identical hashes')
    for name in m['files']:
        p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read('files/'+name))
    if m['repo']=='flux':
        p=root/'.publishing/state.json';state=json.loads(p.read_text())
        state['sources']['images'].update(path='post/flux',history_path='post',previous_paths=['post/stream'])
        p.write_text(json.dumps(state,ensure_ascii=False,indent=2)+'\n')
Path('flux-folder-update.zip').unlink()
